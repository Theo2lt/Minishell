/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tokenisation.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sredjini <sredjini@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/24 01:25:46 by sredjini          #+#    #+#             */
/*   Updated: 2022/07/26 06:13:06 by sredjini         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

char    if_quote(char c, int *i)
{ 
    if (c != '\'' && c != '"')
                return (' ');
    *i = *i + 1;        
    return (c);
}

static int id_redir(char *str, char *c, int i, t_cmd *cmd)
{
    int j;
    
    *c = str[i];
    if (str[i + 1] && str[i + 1] == '>')
    {
        *c = *c * -1;
        i++;
    }
    j = i; 
    while(str[j] && str[j] == ' ')
        j++;
    cmd->redi = 1;
    return (j);
}

static int id_files(char *str, char *c, int i, t_cmd *cmd)
{
    int     j;
    char    s;

    s = 0;
  //  printf("before i == %c s == %c i == %d\n", str[i], s, i);
    s = if_quote(str[i], &i);
   // printf("after i == %c s == %c i == %d\n", str[i], s, i);
    j = i;
    while (str[j] && str[j] != s  && str[j + 1] != '<' && str[j + 1] != '>')
        j++;
    printf("str[%c]\n",str[j]);
    cmd->redi = 0;
    cmd->files = 1;
    openfiles(str + i, *c, j - i, cmd);
    return (j);
}

static int id_cmd(char *str, int i, char c, t_cmd *cmd)
{
    int j;

    c = if_quote(c, &i);
    j = i;
    while (str[j] && str[j] != c  && str[j + 1] != '<' && str[j + 1] != '>')
    {
 //       printf(" OK str[%c] c=[%c], i == %d, j==%d \n", str[j], c,i,j);
        j++;      
    }
 //  printf("%d == i %d == j\n", i, j);
    saves_cmd(str, i, j, cmd);
    cmd->cmd = 1;
    cmd->arg = 0;
    return (j);
}

static int id_arg(char *str, int i, char c, t_cmd *cmd)
{
    int j;

    c = if_quote(c, &i);
    j = i;
    while (str[j] && str[j] != c  && str[j + 1] != '<' && str[j + 1] != '>')
     {
        j++;
     }   
    cmd->arg = 0;
   saves_arg(str, i , j, cmd);
 //   printf("ET apres");
    return (j); 
}

static t_cmd  *pars_attribution(t_cmd *cmd)
{
    cmd = malloc(sizeof(t_cmd));
    cmd->redi = 0;
    cmd->files = 1;
    cmd->cmd = 0;
    cmd->arg = 1;
    cmd->strarg = NULL;
    cmd->strcmd = NULL;
    cmd->outfile = 1;
    cmd->infile = 0;
    cmd->nb_arg = 0;
    return (cmd);
}

 char   *token(char *str, t_cmd *cmd)
 {
    char    c;
    int     i;
    
    c = 0;
    i = 0;
  cmd = pars_attribution(cmd);
    ft_negative_quote(str, NULL);
    while (/*i < ft_strlen(str) &&*/ str[i] && str[i] != '|')
    {
        if (!cmd->redi && cmd->files && (str[i] == '<' || str[i] == '>'))
        {
       //     printf("redi %c %d\n", str[i], i);
            i = id_redir(str, &c, i, cmd);
        }
        else if (cmd->redi && cmd->files && (str[i] != ' '))
        {
            printf("file %c %d\n", str[i], i);
            i = id_files(str, &c, i, cmd);
        }
        else if (!cmd->redi && cmd->files && !cmd->cmd && cmd->arg && str[i] != ' ')
        {
            printf("ICI %c\n", str[i]);
            i = id_cmd(str, i, str[i], cmd);
            printf("cmd %c %d\n", str[i], i);
        }
        else if (!cmd->redi && cmd->files && cmd->cmd  && str[i] != ' ')
        {
           printf("arg %c %d\n", str[i], i);
            i = id_arg(str, i, str[i], cmd);
        }
         if (!str[i])
             break ;
        i++;
    }
    return (NULL);
    if (str[i] == '|')
        {
            token(str + i + 1, cmd->next);
        }
 }
 
void   open_double_outfiles(char *str, t_cmd *cmd)
{

    if (cmd->outfile != 1)
        close(cmd->outfile);
    cmd->outfile = open(str, O_WRONLY | O_CREAT | O_APPEND, 0666);
    if (cmd->outfile == -1)
        printf("Error outfile\n");  // a gerer (free + exit la commande en cours
}

 void   openfiles(char *str, char c, int j, t_cmd *cmd)
 {
    char    *savefile;

    savefile = ft_substr(str, 0, j);
    if (!savefile)
        return ;
    ft_positive_char(savefile);
  //  cmd->file = ft_substr(str, 0, j);
    printf("%s == files ,%c = char, %d = j\n", savefile, *str, j);
    if (c == '>')
    {
        if (cmd->outfile != 1)
            close(cmd->outfile);
        cmd->outfile = open(savefile, O_WRONLY | O_CREAT | O_TRUNC, 0666);
        if (cmd->outfile == -1)
            printf("Error outfile\n");  // a gerer (free + exit la commande en cours)
    }
    else if (c < 0)
        open_double_outfiles(savefile, cmd);
    else if (c == '<')
      { 
        if (cmd->infile != 0)
            close(cmd->infile); 
        cmd->infile = open(savefile, O_RDONLY, 0666);
        if (cmd->infile == -1)
            printf("Error infile\n");  // a gerer (free + exit la commande en cours)
      }
    printf("%d fd outfile\n",cmd->outfile);
  //  printf("%d fd infile",cmd->infile); 
    if (savefile)
        free(savefile);
        
 }
 
 void   saves_cmd(char *str, int i, int j, t_cmd *cmd)
 {

    cmd->strcmd = ft_substr(str + i, 0, j - i);  
    printf("COMMAND NEG%s\n",cmd->strcmd);
    ft_positive_char(cmd->strcmd);
    printf("COMMAND %s\n",cmd->strcmd);
 }

 void   saves_arg(char *str, int i, int j, t_cmd *cmd)
 {
    char    *tmp;
    char    *save;
    char    *first;
    if(!cmd->strarg)
    {
        cmd->strarg = malloc(sizeof(char *));
         cmd->strarg[0] = '\0';
    }
    first = cmd->strarg;
    tmp = ft_substr(str + i, 0, j - i);
    save = ft_strjoin(tmp, " ");
    free(tmp);
    printf("AVANR SUBSTR str[%c] str[%c] %d == i, %d j\n",str[i], str[j - 1], i, j);
    cmd->strarg = ft_strjoin(first, save);
    ft_positive_char(cmd->strarg);
    free(save);
    free(first);
    printf("ARGUMENT %s\n",cmd->strarg);
 } 